# MedMinder – Parent PIN Build

This build **removes Family/Guardian view** and adds a **Parent Code** gate so only a parent on the child's device can log doses.

## Run
```bash
npm install
npm run dev
# http://localhost:3000
```

## How it works
1. Parent goes to **Profile → Parent Code**, sets a 4–6 digit code.
2. On **Meds** page, tapping **Log dose** opens a modal asking for the code.
3. If the code is correct, the dose is recorded (progress increments) and saved for this user.

> Demo stores data in `localStorage`. In production, store a hashed PIN on your backend and write dose logs as auditable records.

## Optional Firebase
Add `.env.local` to use real email/password auth; otherwise a demo user is used.