import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (pathname.startsWith("/api") || pathname.startsWith("/_next") || pathname.startsWith("/login") || pathname.startsWith("/signup") || pathname.startsWith("/plan") || pathname.startsWith("/calendar")) {
    return NextResponse.next();
  }
  const token = req.cookies.get("access_token")?.value;
  if (!token && pathname === "/") {
    const url = req.nextUrl.clone();
    url.pathname = "/plan";
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}
