export const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://127.0.0.1:8000/v1";

export async function apiGet(path: string, init?: RequestInit) {
  const r = await fetch(path.startsWith("/api/") ? path : `/api${path}`, { cache: "no-store", ...init });
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

export async function apiPost(path: string, body?: any, init?: RequestInit) {
  const r = await fetch(path.startsWith("/api/") ? path : `/api${path}`, {
    method: "POST",
    headers: { "content-type": "application/json", ...(init?.headers || {}) },
    body: body ? JSON.stringify(body) : undefined,
    ...init,
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(typeof data === "string" ? data : (data.detail || JSON.stringify(data)));
  return data;
}
