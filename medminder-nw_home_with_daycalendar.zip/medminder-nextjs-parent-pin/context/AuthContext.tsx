"use client";
import { createContext, useContext, useEffect, useState } from "react";
import { initializeApp, getApps } from "firebase/app";
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, updateProfile } from "firebase/auth";

export type User = { uid: string; email: string | null; displayName?: string | null; dob?: string | null; role?: "patient"; };

type AuthCtx = {
  user: User | null;
  loading: boolean;
  login: (email:string, password:string)=>Promise<void>;
  register: (name:string, dob: string, email:string, password:string)=>Promise<void>;
  logout: ()=>Promise<void>;
  // parent PIN helpers
  setParentPin: (pin: string)=>void;
  hasParentPin: ()=>boolean;
  verifyParentPin: (pin: string)=>boolean;
};

const Ctx = createContext<AuthCtx | null>(null);

function createFirebaseAuth(){
  const config = {
    apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || "demo",
    authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || "localhost",
    projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || "demo",
  };
  const app = getApps().length ? getApps()[0] : initializeApp(config as any);
  return getAuth(app);
}

export function AuthProvider({ children }:{children: React.ReactNode}){
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const auth = createFirebaseAuth();

  useEffect(()=>{
    const unsub = onAuthStateChanged(auth, (fbUser)=>{
      if (fbUser) {
        const dob = (globalThis.localStorage?.getItem(`dob:${fbUser.uid}`)) || null;
        const profile: User = { uid: fbUser.uid, email: fbUser.email, displayName: fbUser.displayName || undefined, dob, role: "patient" };
        localStorage.setItem(`userProfile:${profile.uid}`, JSON.stringify(profile));
        setUser(profile);
      } else {
        // demo user if not using Firebase
        const raw = localStorage.getItem("demoUser");
        if (raw) { setUser(JSON.parse(raw)); }
        else {
          const demo: User = { uid: "demo", email: "demo@example.com", displayName: "Selin Ozsaracoglu", dob: "2007-08-06", role: "patient" };
          localStorage.setItem("demoUser", JSON.stringify(demo));
          setUser(demo);
        }
      }
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const login = async (email:string, password:string) => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      const fb = auth.currentUser!;
      const profile: User = { uid: fb.uid, email: fb.email, displayName: fb.displayName || undefined, dob: localStorage.getItem(`dob:${fb.uid}`) || undefined, role: "patient" };
      localStorage.setItem(`userProfile:${profile.uid}`, JSON.stringify(profile));
      setUser(profile);
    } catch {
      const demo: User = { uid: "demo", email, displayName: "Selin Ozsaracoglu", dob: "2007-08-06", role: "patient" };
      localStorage.setItem("demoUser", JSON.stringify(demo));
      setUser(demo);
    }
  };

  const register = async (name:string, dob:string, email:string, password:string) => {
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(cred.user, { displayName: name });
      localStorage.setItem(`dob:${cred.user.uid}`, dob);
      const profile: User = { uid: cred.user.uid, email, displayName: name, dob, role: "patient" };
      localStorage.setItem(`userProfile:${profile.uid}`, JSON.stringify(profile));
      setUser(profile);
    } catch {
      const demo: User = { uid: "demo", email, displayName: name, dob, role: "patient" };
      localStorage.setItem("demoUser", JSON.stringify(demo));
      setUser(demo);
    }
  };

  const logout = async () => {
    try { await signOut(auth); } catch {}
    localStorage.removeItem("demoUser");
    setUser(null);
  };

  const pinKey = (uid: string) => `parentPin:${uid}`;
  const setParentPin = (pin: string) => { if (user) localStorage.setItem(pinKey(user.uid), pin); };
  const hasParentPin = () => !!(user && localStorage.getItem(pinKey(user.uid)));
  const verifyParentPin = (pin: string) => !!(user && localStorage.getItem(pinKey(user.uid)) === pin);

  return <Ctx.Provider value={{ user, loading, login, register, logout, setParentPin, hasParentPin, verifyParentPin }}>{children}</Ctx.Provider>;
}

export function useAuth(){
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}