"use client";
import { useMemo, useState } from "react";
import MarkTakenButton from "./MarkTakenButton";
import { useCustomEvents } from "./EventEditor";

type Dose = {
  id: string;
  medication_name: string;
  scheduled_at: string;
  taken_at?: string | null;
};

function startOfMonth(d: Date) { return new Date(d.getFullYear(), d.getMonth(), 1); }
function endOfMonth(d: Date) { return new Date(d.getFullYear(), d.getMonth()+1, 0); }
function fmtYMD(d: Date) { return d.toISOString().slice(0,10); }

export default function CalendarMonth({ doses }: { doses: Dose[] }) {
  const [cursor, setCursor] = useState(new Date());
  const { events } = useCustomEvents();

  const grid = useMemo(()=>{
    const start = startOfMonth(cursor);
    const end = endOfMonth(cursor);
    const firstWeekday = (new Date(start)).getDay();
    const days: Date[] = [];
    for (let i=0;i<firstWeekday;i++) days.push(new Date(start.getTime() - (firstWeekday - i)*86400000));
    for (let d=1; d<=end.getDate(); d++) days.push(new Date(cursor.getFullYear(), cursor.getMonth(), d));
    while (days.length % 7 !== 0) days.push(new Date(days[days.length-1].getTime() + 86400000));
    return days;
  }, [cursor]);

  const byDate = useMemo(()=>{
    const m = new Map<string, { doses: Dose[]; events: any[] }>();
    for (const d of doses) {
      const key = d.scheduled_at.slice(0,10);
      if (!m.has(key)) m.set(key, { doses: [], events: [] });
      m.get(key)!.doses.push(d);
    }
    for (const ev of events) {
      const key = ev.date;
      if (!m.has(key)) m.set(key, { doses: [], events: [] });
      m.get(key)!.events.push(ev);
    }
    return m;
  }, [doses, events]);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <button className="px-2 py-1 border rounded" onClick={()=>setCursor(new Date(cursor.getFullYear(), cursor.getMonth()-1, 1))}>←</button>
        <h2 className="font-semibold">{cursor.toLocaleString(undefined, { month: "long", year: "numeric" })}</h2>
        <div className="space-x-2">
          <button className="px-2 py-1 border rounded" onClick={()=>setCursor(new Date())}>Today</button>
          <button className="px-2 py-1 border rounded" onClick={()=>setCursor(new Date(cursor.getFullYear(), cursor.getMonth()+1, 1))}>→</button>
        </div>
      </div>
      <div className="grid grid-cols-7 gap-2">
        {["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].map(w=>(<div key={w} className="text-xs text-gray-500">{w}</div>))}
        {grid.map((d, idx)=>{
          const ymd = fmtYMD(d);
          const isThisMonth = d.getMonth() === cursor.getMonth();
          // @ts-ignore
          const cell = byDate.get(ymd);
          return (
            <div key={idx} className={`border rounded p-2 min-h-[110px] ${isThisMonth? "bg-white": "bg-gray-50"}`}>
              <div className="text-xs text-gray-500">{d.getDate()}</div>
              <div className="space-y-1 mt-1">
                {cell?.events.map((ev:any)=>(
                  <div key={ev.id} className="text-xs rounded px-2 py-1 bg-gray-200" title={ev.notes || ""}>
                    {ev.time? `[${ev.time}] `: ""}{ev.title}
                  </div>
                ))}
                {cell?.doses.map((ds: Dose) => {
                  const time = new Date(ds.scheduled_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
                  const taken = !!ds.taken_at;
                  return (
                    <div key={ds.id} className={`text-xs rounded px-2 py-1 flex items-center justify-between ${taken? "bg-green-100 line-through": "bg-amber-100"}`}>
                      <span>{time} • {ds.medication_name}</span>
                      <MarkTakenButton doseId={String(ds.id)} initialTaken={taken} />
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
      <div className="text-sm text-gray-600 pt-2">
        Doses come from your backend via <code>/api/doses?window=month</code>. Personal events are stored locally on your device.
      </div>
    </div>
  );
}
