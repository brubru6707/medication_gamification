"use client";
import { useEffect, useMemo, useState } from "react";
import MarkTakenButton from "./MarkTakenButton";

type Dose = {
  id: string;
  medication_name: string;
  scheduled_at: string;
  taken_at?: string | null;
};

export default function DailySchedule() {
  const [doses, setDoses] = useState<Dose[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let done = false;
    (async () => {
      try {
        const r = await fetch("/api/doses?window=today", { cache: "no-store" });
        const data = await r.json();
        if (!r.ok) throw new Error(typeof data === "string" ? data : (data.detail || "Failed to load doses"));
        const items = Array.isArray(data) ? data : (data.items ?? []);
        if (!done) setDoses(items);
      } catch (e: any) {
        if (!done) setError(e.message || String(e));
      } finally {
        if (!done) setLoading(false);
      }
    })();
    return () => { done = true; };
  }, []);

  const byHour = useMemo(() => {
    const map = new Map<number, Dose[]>();
    for (const d of doses) {
      const dt = new Date(d.scheduled_at);
      const h = dt.getHours();
      if (!map.has(h)) map.set(h, []);
      map.get(h)!.push(d);
    }
    // sort each hour bucket by time
    for (const [h, arr] of map.entries()) {
      arr.sort((a,b) => new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime());
    }
    return Array.from(map.entries()).sort((a,b) => a[0]-b[0]);
  }, [doses]);

  if (loading) return <div className="text-sm text-gray-600">Loading today&apos;s schedule…</div>;
  if (error) return <div className="text-sm text-red-600">{error}</div>;

  if (doses.length === 0) {
    return <div className="text-sm text-gray-600">No medication scheduled for today.</div>;
  }

  return (
    <div className="space-y-4">
      {byHour.map(([h, items]) => (
        <div key={h} className="rounded-2xl p-4 border shadow-sm bg-gradient-to-br from-white to-gray-50">
          <div className="text-sm font-semibold mb-2">
            {String(h).padStart(2, "0")}:00
          </div>
          <ul className="space-y-2">
            {items.map((d) => {
              const time = new Date(d.scheduled_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
              const taken = !!d.taken_at;
              return (
                <li key={d.id} className={`flex items-center justify-between rounded-xl px-3 py-2 ${taken ? "bg-green-100 line-through" : "bg-blue-50"}`}>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-current opacity-60"></div>
                    <div className="text-sm">
                      <div className="font-medium">{d.medication_name}</div>
                      <div className="text-xs text-gray-600">{time}</div>
                    </div>
                  </div>
                  <MarkTakenButton doseId={String(d.id)} initialTaken={taken} />
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </div>
  );
}
