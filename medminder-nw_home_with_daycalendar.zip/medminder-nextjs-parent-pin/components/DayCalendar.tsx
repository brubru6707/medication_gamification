"use client";
import { useEffect, useMemo, useState } from "react";
import MarkTakenButton from "./MarkTakenButton";

type Dose = {
  id: string;
  medication_name: string;
  scheduled_at: string; // ISO
  taken_at?: string | null;
};

function groupByHour(doses: Dose[]) {
  const m = new Map<number, Dose[]>();
  for (let h = 0; h < 24; h++) m.set(h, []);
  for (const d of doses) {
    const dt = new Date(d.scheduled_at);
    const h = dt.getHours();
    if (!m.has(h)) m.set(h, []);
    m.get(h)!.push(d);
  }
  for (const [h, arr] of m.entries()) {
    arr.sort((a,b)=> new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime());
  }
  return m;
}

export default function DayCalendar() {
  const [doses, setDoses] = useState<Dose[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let done = false;
    (async () => {
      try {
        const r = await fetch("/api/doses?window=today", { cache: "no-store" });
        const data = await r.json();
        if (!r.ok) throw new Error(typeof data === "string" ? data : (data.detail || "Failed to load"));
        const items = Array.isArray(data) ? data : (data.items ?? []);
        if (!done) setDoses(items);
      } catch (e:any) {
        if (!done) setError(e.message || String(e));
      } finally {
        if (!done) setLoading(false);
      }
    })();
    return () => { done = true; };
  }, []);

  const byHour = useMemo(()=> groupByHour(doses), [doses]);
  const todayStr = new Date().toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" });

  return (
    <section className="w-full">
      <div className="flex items-baseline justify-between mb-3">
        <h2 className="text-xl font-semibold">Today’s schedule</h2>
        <div className="text-sm text-gray-600">{todayStr}</div>
      </div>
      {loading && <div className="text-sm text-gray-600">Loading…</div>}
      {error && <div className="text-sm text-red-600">{error}</div>}
      {!loading && !error && (
        <div className="grid grid-cols-[72px_1fr] gap-x-3">
          {/* Left column: hours */}
          <div className="flex flex-col">
            {Array.from({ length: 24 }, (_, i) => (
              <div key={i} className="h-16 flex items-start justify-end pr-1 text-xs text-gray-500">
                {String(i).padStart(2, "0")}:00
              </div>
            ))}
          </div>

          {/* Right column: lanes */}
          <div className="relative">
            {/* background hour grid */}
            <div className="absolute inset-0 pointer-events-none">
              {Array.from({ length: 24 }, (_, i) => (
                <div key={i} className="h-16 border-b last:border-b-0 border-gray-200"></div>
              ))}
            </div>

            {/* events per hour */}
            <div className="relative">
              {Array.from({ length: 24 }, (_, i) => {
                const items = byHour.get(i) || [];
                return (
                  <div key={i} className="h-16 flex items-center gap-2">
                    {items.length === 0 ? (
                      <div className="text-xs text-gray-300">—</div>
                    ) : (
                      <div className="flex flex-wrap gap-2">
                        {items.map(d => {
                          const time = new Date(d.scheduled_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
                          const taken = !!d.taken_at;
                          return (
                            <div key={d.id} className={`px-3 py-2 rounded-xl shadow-sm border ${taken ? "bg-green-100 border-green-300 line-through" : "bg-indigo-50 border-indigo-200"}`}>
                              <div className="text-xs font-medium">{d.medication_name}</div>
                              <div className="text-[11px] text-gray-600">{time}</div>
                              <div className="mt-1">
                                <MarkTakenButton doseId={String(d.id)} initialTaken={taken} />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
      {!loading && !error && doses.length === 0 && (
        <div className="text-sm text-gray-600 mt-2">No medication scheduled for today.</div>
      )}
    </section>
  );
}
