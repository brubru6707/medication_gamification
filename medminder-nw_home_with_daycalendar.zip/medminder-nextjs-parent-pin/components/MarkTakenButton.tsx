"use client";
import { useState } from "react";

export default function MarkTakenButton({ doseId, initialTaken }: { doseId: string; initialTaken?: boolean }) {
  const [taken, setTaken] = useState(!!initialTaken);
  const [busy, setBusy] = useState(false);
  const onClick = async () => {
    if (taken || busy) return;
    setBusy(true);
    try {
      const r = await fetch(`/api/doses/${doseId}/taken`, { method: "POST" });
      if (!r.ok) throw new Error(await r.text());
      setTaken(true);
    } catch (e) {
      alert(String(e));
    } finally {
      setBusy(false);
    }
  };
  return (
    <button
      onClick={onClick}
      disabled={taken || busy}
      className={`px-3 py-1 rounded text-sm ${taken ? "bg-green-600 text-white" : "bg-gray-200 hover:bg-gray-300"}`}
      aria-label={taken ? "Dose marked taken" : "Mark dose as taken"}
    >
      {taken ? "Taken ✓" : busy ? "Saving..." : "Mark taken"}
    </button>
  );
}
