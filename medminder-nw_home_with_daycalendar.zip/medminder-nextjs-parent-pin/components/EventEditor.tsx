"use client";
import { useEffect, useState } from "react";

type EventItem = { id: string; title: string; date: string; time?: string; notes?: string };

function loadEvents(): EventItem[] {
  if (typeof window === "undefined") return [];
  try { return JSON.parse(localStorage.getItem("custom_events") || "[]"); } catch { return []; }
}
function saveEvents(evs: EventItem[]) {
  if (typeof window === "undefined") return;
  localStorage.setItem("custom_events", JSON.stringify(evs));
}

export function useCustomEvents() {
  const [events, setEvents] = useState<EventItem[]>([]);
  useEffect(() => { setEvents(loadEvents()); }, []);
  const add = (e: Omit<EventItem, "id">) => {
    const next = [{ id: crypto.randomUUID(), ...e }, ...events];
    setEvents(next); saveEvents(next);
  };
  const remove = (id: string) => {
    const next = events.filter(x => x.id !== id);
    setEvents(next); saveEvents(next);
  };
  return { events, add, remove };
}

export default function EventEditor() {
  const { events, add, remove } = useCustomEvents();
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [notes, setNotes] = useState("");

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Add personal event</h3>
      <div className="grid gap-2 sm:grid-cols-2">
        <input className="border p-2 rounded" value={title} onChange={e=>setTitle(e.target.value)} placeholder="Event title" />
        <input className="border p-2 rounded" type="date" value={date} onChange={e=>setDate(e.target.value)} />
        <input className="border p-2 rounded" type="time" value={time} onChange={e=>setTime(e.target.value)} />
        <input className="border p-2 rounded sm:col-span-2" value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Notes (optional)" />
      </div>
      <button
        className="px-3 py-2 rounded bg-blue-600 text-white disabled:opacity-50"
        disabled={!title || !date}
        onClick={()=>{ add({ title, date, time, notes }); setTitle(""); setDate(""); setTime(""); setNotes(""); }}
      >Add event</button>

      <div className="pt-3">
        <h4 className="font-medium mb-2">Your events</h4>
        <ul className="space-y-2">
          {events.map(ev=>(
            <li key={ev.id} className="border p-2 rounded flex items-center justify-between">
              <div>
                <div className="font-medium">{ev.title}</div>
                <div className="text-sm text-gray-600">{[ev.date, ev.time].filter(Boolean).join(" ")}{ev.notes? " — "+ev.notes: ""}</div>
              </div>
              <button onClick={()=>remove(ev.id)} className="text-sm text-red-600">Remove</button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
