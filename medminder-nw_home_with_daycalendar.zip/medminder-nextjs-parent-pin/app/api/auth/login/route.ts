const BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://127.0.0.1:8000/v1";

export async function POST(req: Request) {
  const body = await req.text();
  const r = await fetch(`${BASE}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body,
    credentials: "include",
  });
  // Stream body and pass through critical headers (including Set-Cookie)
  const headers = new Headers();
  const ct = r.headers.get("content-type");
  if (ct) headers.set("content-type", ct);
  const sc = r.headers.get("set-cookie");
  if (sc) headers.set("set-cookie", sc);
  return new Response(r.body, { status: r.status, headers });
}
