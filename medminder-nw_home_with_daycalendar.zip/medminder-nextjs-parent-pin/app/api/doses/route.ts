import { NextResponse } from "next/server";
const BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://127.0.0.1:8000/v1";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const windowParam = url.searchParams.get("window") ?? "month";
  const r = await fetch(`${BASE}/doses?window=${encodeURIComponent(windowParam)}`, { cache: "no-store" });
  const data = await r.json();
  return NextResponse.json(data, { status: r.status });
}
