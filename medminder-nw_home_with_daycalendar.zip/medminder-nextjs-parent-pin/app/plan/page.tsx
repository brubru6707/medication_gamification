"use client";
import { useRouter } from "next/navigation";

export default function PlanChoicePage() {
  const router = useRouter();
  return (
    <main className="min-h-screen flex items-center justify-center p-6 bg-gray-50">
      <div className="w-full max-w-md bg-white shadow rounded-2xl p-6 space-y-4">
        <h1 className="text-2xl font-bold text-center">Welcome to MedMinder</h1>
        <p className="text-center text-gray-600">Choose how you want to use the app.</p>
        <div className="grid gap-3">
          <button className="p-4 rounded-xl border hover:bg-gray-50 text-left" onClick={()=> location.href="/login"}>
            <div className="font-semibold">Family plan</div>
            <div className="text-sm text-gray-600">Use the Parent/Child login.</div>
          </button>
          <button className="p-4 rounded-xl border hover:bg-gray-50 text-left" onClick={()=> location.href="/login/individual"}>
            <div className="font-semibold">Individual plan</div>
            <div className="text-sm text-gray-600">Simple login for a single user account.</div>
          </button>
        </div>
      </div>
    </main>
  );
}
