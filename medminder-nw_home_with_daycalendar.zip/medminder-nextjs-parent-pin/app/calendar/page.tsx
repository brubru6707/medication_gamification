"use client";
import { useEffect, useState } from "react";
import CalendarMonth from "@/components/Calendar";
import EventEditor from "@/components/EventEditor";

export default function CalendarPage() {
  const [doses, setDoses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let done = false;
    (async () => {
      try {
        const r = await fetch("/api/doses?window=month", { cache: "no-store" });
        const data = await r.json();
        if (!r.ok) throw new Error(typeof data === "string" ? data : (data.detail || "Failed to load doses"));
        const items = Array.isArray(data) ? data : (data.items ?? []);
        if (!done) setDoses(items);
      } catch (e: any) {
        if (!done) setError(e.message || String(e));
      } finally {
        if (!done) setLoading(false);
      }
    })();
    return () => { done = true; };
  }, []);

  return (
    <main className="max-w-5xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold">Calendar</h1>
      {loading ? <div className="text-sm text-gray-600">Loading…</div> :
       error ? <div className="text-sm text-red-600">{error}</div> :
       <CalendarMonth doses={doses} />}
      <div className="border-t pt-6">
        <EventEditor />
      </div>
    </main>
  );
}
