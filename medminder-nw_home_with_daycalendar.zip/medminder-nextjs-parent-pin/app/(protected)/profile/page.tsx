"use client";
import NavTabs from "@/components/NavTabs";
import { useAuth } from "@/context/AuthContext";
import { useEffect, useState } from "react";

export default function ProfilePage(){
  const { user, logout, setParentPin, hasParentPin } = useAuth();
  const [pin, setPin] = useState("");
  const [saved, setSaved] = useState(false);
  const [hasPin, setHasPin] = useState(false);

  useEffect(()=>{ setHasPin(hasParentPin()); }, [hasParentPin]);

  const save = () => {
    if (!/^[0-9]{4,6}$/.test(pin)) { alert("Use a 4–6 digit code."); return; }
    setParentPin(pin);
    setSaved(true); setHasPin(true);
    setTimeout(()=>setSaved(false), 1200);
    setPin("");
  };

  return (
    <div>
      <NavTabs />
      <h1 className="text-3xl font-bold mb-4">Profile</h1>
      <div className="card card-pad space-y-4">
        <div>
          <h2 className="text-lg font-semibold mb-2">Personal Information</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div><div className="text-slate-500 text-sm">Name</div><div className="font-medium">{user?.displayName || "—"}</div></div>
            <div><div className="text-slate-500 text-sm">Email</div><div className="font-medium">{user?.email || "—"}</div></div>
            <div><div className="text-slate-500 text-sm">Date of Birth</div><div className="font-medium">{user?.dob || "—"}</div></div>
          </div>
        </div>

        <div className="card card-pad">
          <h2 className="text-lg font-semibold">Parent Code</h2>
          <p className="text-sm text-slate-600 mb-2">Require a parent/guardian code to log doses from this device.</p>
          <div className="flex gap-2">
            <input
              type="password"
              inputMode="numeric"
              pattern="[0-9]*"
              placeholder={hasPin ? "Change code (4–6 digits)" : "Set code (4–6 digits)"}
              value={pin}
              onChange={e=>setPin(e.target.value.replace(/\D/g, '').slice(0,6))}
            />
            <button className="btn btn-primary" onClick={save}>{hasPin ? "Update" : "Set code"}</button>
          </div>
          {saved && <div className="text-sm text-green-700 mt-2">Saved.</div>}
          <div className="text-xs text-slate-500 mt-2">Tip: Keep this code private. You can change it anytime.</div>
        </div>

        <div className="pt-2"><button onClick={logout} className="btn btn-ghost">Sign out</button></div>
      </div>
    </div>
  );
}