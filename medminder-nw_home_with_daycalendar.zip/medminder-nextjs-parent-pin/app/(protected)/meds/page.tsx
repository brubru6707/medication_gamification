"use client";
import NavTabs from "@/components/NavTabs";
import MedicationCard, { Medication } from "@/components/MedicationCard";
import AddMedicationDialog from "@/components/AddMedicationDialog";
import ParentPinModal from "@/components/ParentPinModal";
import { useEffect, useState } from "react";
import { useAuth } from "@/context/AuthContext";

const seed: Medication[] = [
  { id: "1", name: "Lisinopril", dosage: "10mg", frequency: "Once daily", times: ["08:00"], progress: { taken: 6, total: 7 } },
  { id: "2", name: "Metformin", dosage: "500mg", frequency: "Twice daily", times: ["08:00","20:00"], progress: { taken: 12, total: 14 } },
];

function load(uid: string | null){
  if (!uid) return seed;
  try { const raw = localStorage.getItem(`meds:${uid}`); return raw ? JSON.parse(raw) : seed; } catch { return seed; }
}
function save(uid: string | null, meds: Medication[]){
  if (!uid) return; localStorage.setItem(`meds:${uid}`, JSON.stringify(meds));
}

export default function MedsPage(){
  const { user, verifyParentPin, hasParentPin } = useAuth();
  const uid = user?.uid || null;

  const [meds, setMeds] = useState<Medication[]>(()=> load(uid));
  const [pinOpen, setPinOpen] = useState(false);
  const [pendingMedId, setPendingMedId] = useState<string | null>(null);
  useEffect(()=>{ setMeds(load(uid)); }, [uid]);
  useEffect(()=>{ save(uid, meds); }, [uid, meds]);

  const addMed = (m: Medication) => setMeds(prev => [...prev, { ...m, progress: { taken: 0, total: m.times.length * 7 } }]);
  const requestLog = (id: string) => { setPendingMedId(id); setPinOpen(true); };

  const onVerify = (pin: string) => {
    if (!verifyParentPin(pin)) {
      alert("Incorrect parent code.");
      return;
    }
    setPinOpen(false);
    if (!pendingMedId) return;
    setMeds(prev => prev.map(m => m.id === pendingMedId ? ({ ...m, progress: { taken: (m.progress?.taken || 0) + 1, total: m.progress?.total || m.times.length * 7 } }) : m));
    setPendingMedId(null);
  };

  return (
    <div>
      <NavTabs />
      <div className="flex items-center justify-between mb-3">
        <h1 className="text-3xl font-bold">My Medications</h1>
        <AddMedicationDialog onAdd={addMed} />
      </div>
      {!hasParentPin() && (
        <div className="card card-pad mb-3 text-sm">
          <div className="font-semibold mb-1">Parent code not set</div>
          <div>To prevent kids logging doses themselves, set a code in <kbd>Profile → Parent Code</kbd>. Logging will ask for that code.</div>
        </div>
      )}
      <div className="space-y-3">
        {meds.map(m => <MedicationCard key={m.id} med={m} onLog={()=>requestLog(m.id)} />)}
      </div>
      <ParentPinModal open={pinOpen} onClose={()=>setPinOpen(false)} onVerify={onVerify} />
    </div>
  );
}