import dynamic from "next/dynamic";
const DayCalendar = dynamic(() => import("@/components/DayCalendar"), { ssr: false });

export default function HomePage() {
  return (
    <main className="max-w-4xl mx-auto p-6 space-y-6">
      <header className="flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-bold">Welcome back</h1>
          <p className="text-sm text-gray-600">Here’s your day at a glance</p>
        </div>
        <a href="/calendar" className="text-sm underline">Open full calendar</a>
      </header>
      <DayCalendar />
    </main>
  );
}
