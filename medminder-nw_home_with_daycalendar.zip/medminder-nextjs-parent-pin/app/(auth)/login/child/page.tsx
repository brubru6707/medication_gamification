"use client";
import { useState } from "react";

export default function ChildLoginPage() {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const r = await fetch("/api/auth/child/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ identifier, password, role: "child" })
      });
      if (!r.ok) throw new Error(await r.text());
      window.location.href = "/";
    } catch (e:any) {
      setError(e.message || "Login failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center p-6 bg-gray-50">
      <form onSubmit={onSubmit} className="w-full max-w-md bg-white shadow rounded-2xl p-6 space-y-4">
        <h1 className="text-2xl font-bold text-center">Child Login</h1>
        <div className="grid gap-3">
          <input className="border rounded p-2" placeholder="Email / Username / ID" value={identifier} onChange={e=>setIdentifier(e.target.value)} />
          <input className="border rounded p-2" type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
        </div>
        {error && <div className="text-sm text-red-600">{error}</div>}
        <button disabled={busy} className="w-full p-2 rounded bg-blue-600 text-white">{busy? "Signing in…" : "Sign in"}</button>
        <p className="text-xs text-gray-600 text-center">No account? <a className="underline" href="/signup/child">Create one</a></p>
      </form>
    </main>
  );
}
