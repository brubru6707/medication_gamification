"use client";
import { useState } from "react";

export default function ChildSignupPage() {
  const [name, setName] = useState("");
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const r = await fetch("/api/auth/child/signup", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name, identifier, password, role: "child", plan: "family" }),
      });
      if (!r.ok) throw new Error(await r.text());
      window.location.href = "/login/child";
    } catch (e:any) {
      setError(e.message || "Signup failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center p-6 bg-gray-50">
      <form onSubmit={onSubmit} className="w-full max-w-md bg-white shadow rounded-2xl p-6 space-y-4">
        <h1 className="text-2xl font-bold text-center">Create Child Account</h1>
        <div className="grid gap-3">
          <input className="border rounded p-2" placeholder="Full name" value={name} onChange={e=>setName(e.target.value)} />
          <input className="border rounded p-2" placeholder="Email / Username / ID" value={identifier} onChange={e=>setIdentifier(e.target.value)} />
          <input className="border rounded p-2" type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
        </div>
        {error && <div className="text-sm text-red-600">{error}</div>}
        <button disabled={busy} className="w-full p-2 rounded bg-blue-600 text-white">{busy? "Creating…" : "Create account"}</button>
        <p className="text-xs text-gray-600 text-center">Already have an account? <a className="underline" href="/login/child">Sign in</a></p>
      </form>
    </main>
  );
}
