"use client";
import { useAuth } from "@/context/AuthContext";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function SignupPage(){
  const { register } = useAuth();
  const r = useRouter();
  const [name, setName] = useState("");
  const [dob, setDob] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div className="min-h-[80vh] flex items-center justify-center">
      <div className="w-full max-w-md card">
        <div className="card-pad">
          <div className="text-center mb-6">
            <div className="text-2xl font-bold">Join MedMinder</div>
            <div className="text-slate-500">Start your medication adherence journey</div>
          </div>
          <form onSubmit={async (e)=>{e.preventDefault(); await register(name, dob, email, password); r.push("/dashboard");}} className="space-y-3">
            <div><label>Full Name</label><input value={name} onChange={e=>setName(e.target.value)} required /></div>
            <div><label>Date of Birth</label><input type="date" value={dob} onChange={e=>setDob(e.target.value)} required /></div>
            <div><label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required /></div>
            <div><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} required /></div>
            <button className="btn btn-primary w-full mt-2">Create Account</button>
          </form>
          <div className="text-center mt-4 text-sm">Already have an account? <Link href="/login" className="text-ink underline">Sign in</Link></div>
        </div>
      </div>
    </div>
  );
}