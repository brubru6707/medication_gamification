# MedMinder Additions: Calendar + Plan + Auth (login & signup)

New pages
- `/plan` – choose Family vs Individual
- Individual: `/login/individual`, `/signup/individual`
- Family hub: `/login`
  - Parent: `/login/parent`, `/signup/parent`
  - Child: `/login/child`, `/signup/child`
- Calendar: `/calendar` (month view, mark doses as taken, add personal events)

API proxies (Next.js → FastAPI `${NEXT_PUBLIC_API_BASE_URL}`)
- `POST /api/auth/login` → `/auth/login`
- `POST /api/auth/signup` → `/auth/signup`
- `POST /api/auth/parent/login` → `/auth/parent/login`
- `POST /api/auth/child/login` → `/auth/child/login`
- `POST /api/auth/parent/signup` → `/auth/parent/signup`
- `POST /api/auth/child/signup` → `/auth/child/signup`
- `GET /api/doses?window=month` → `/doses?window=month`
- `POST /api/doses/:id/taken` → `/doses/:id/taken`

Why you previously saw 404 on login
The individual login form posted to `/auth/login` (a **page** path), which Next.js doesn’t have—so 404.
Now it posts to `/api/auth/login`, a proxy route that forwards to your FastAPI.

Env
```
NEXT_PUBLIC_API_BASE_URL=http://127.0.0.1:8000/v1
```

If the backend sets cookies, enable `credentials: "include"` in the proxies and configure CORS accordingly.
