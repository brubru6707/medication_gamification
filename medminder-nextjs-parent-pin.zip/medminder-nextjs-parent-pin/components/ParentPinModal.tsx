"use client";
import { useState } from "react";
import { X } from "lucide-react";

export default function ParentPinModal({
  open, onClose, onVerify
}:{ open: boolean; onClose: ()=>void; onVerify: (pin: string)=>void }){
  const [pin, setPin] = useState("");
  if (!open) return null;
  return (
    <div className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center">
      <div className="card w-full max-w-sm">
        <div className="card-pad">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Parent Code Required</h3>
            <button className="btn btn-ghost" onClick={onClose}><X size={18} /></button>
          </div>
          <p className="text-sm text-slate-600 mb-3">
            Please hand the device to a parent/guardian to confirm this dose.
          </p>
          <form onSubmit={(e)=>{e.preventDefault(); onVerify(pin);}} className="space-y-3">
            <div>
              <label>Parent Code</label>
              <input
                type="password"
                inputMode="numeric"
                pattern="[0-9]*"
                placeholder="4–6 digits"
                value={pin}
                onChange={e=>setPin(e.target.value.replace(/\D/g, '').slice(0,6))}
                required
              />
            </div>
            <button className="btn btn-primary w-full">Confirm Dose</button>
          </form>
          <div className="text-xs text-slate-500 mt-2">Hint: Set or change this code in Profile → Parent Code.</div>
        </div>
      </div>
    </div>
  );
}