import { NextRequest, NextResponse } from "next/server";
export async function POST(req: NextRequest){
  const { message } = await req.json();
  const reply = String(message || "").toLowerCase().includes("take")
    ? "Great job staying on track! If you miss a dose, tap ‘Log dose’ with a parent code so we keep your streak accurate."
    : "Hi! I'm your MedMinder assistant. Ask me about your medications or schedule.";
  return NextResponse.json({ reply });
}